<!DOCTYPE HTML>
<html>
	<body class="is-preload">
		<div id="page-wrapper">

            <?php
			include("header.php");
			?>
                <section id="main" class="container">
					<header>
						<h2 style="color: black;">All Accounts</h2>
					</header>
				  <?php
                include 'demotable.php';
                ?>
				</section>

			<!-- Footer -->
		<?php
        include("footer.php");
        ?>
	</body>
</html>