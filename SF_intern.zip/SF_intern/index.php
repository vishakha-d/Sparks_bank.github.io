<html>
	<?php
    include("header.php");
    ?>

			<!-- Banner -->
				<section id="banner">
					<h2>Sparks Bank</h2>
					<p>Your accounts are in safe hands..!</p>
					<ul class="actions special">
						<li><a href="transactions.php" class="button primary">Make Transaction</a></li>
						<li><a href="history.php" class="button">Transaction History</a></li>
                        <li><a href="view_all.php" class="button">View Users</a></li>
					</ul>
				</section>

			
<?php
include("footer.php");
?>
	</body>
</html>