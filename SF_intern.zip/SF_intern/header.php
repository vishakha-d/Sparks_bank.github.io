<head>
		<title>Sparks Bank</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" type="text/css" href="style.css"/>  

	</head>
	<body class="landing is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1><a href="index.php">Sparks Bank</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.php">Home</a></li>
							</ul>
					</nav>
				</header>